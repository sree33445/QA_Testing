import React from 'react'
import LoginForm from '../components/loginsignup/Login'

const page = () => {
  return (
    <div>
        <LoginForm />
    </div>
  )
}

export default page