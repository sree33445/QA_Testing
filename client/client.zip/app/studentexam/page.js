import React from 'react'
import StudentExam from '../components/student/StudentExam'

const page = () => {
  return (
    <div>
      <StudentExam/>
    </div>
  )
}

export default page