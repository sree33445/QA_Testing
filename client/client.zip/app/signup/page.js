import React from 'react'
import SignupPage from '../components/loginsignup/Signup'

const page = () => {
  return (
    <div>
        <SignupPage />
    </div>
  )
}

export default page