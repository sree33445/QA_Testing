import React from 'react'
import TestPage from '../components/student/TestPage'

const page = () => {
  return (
    <div>
        <TestPage />
    </div>
  )
}

export default page