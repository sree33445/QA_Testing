import React from 'react'
import SuperAdminDashboard from "../components/superadmin/SuperAdminDashboard"

const page = () => {
  return (
    <div>
        <SuperAdminDashboard/>
    </div>
  )
}

export default page